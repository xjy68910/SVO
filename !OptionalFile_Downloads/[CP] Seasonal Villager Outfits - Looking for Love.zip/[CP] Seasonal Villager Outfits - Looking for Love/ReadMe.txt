How to use this compatibility patch with Looking for Love (LfL) https://www.nexusmods.com/stardewvalley/mods/3054

-----------------------------------------------

> LfL and this Looking for Love for SVO Compatibility Patch (LflSVO) will generate a config.json after launching the game with the mod(s) installed. Open both config.json's

> You'll notice some of the config.json options are the same. You want these options to match. 
> Example:

LfL 			  | LfLSVO
--------------------------------------
"DateClint": true | "DateClint": false

You'll want these both to say either true or false depending on if you want the NPC to be a marriage candidate or not. LfL defaults everyone to true, LfLSVO defaults everyone to false.


> LfLSVO will override the younger variants, if you want to use those instead remove LfLSVO. 
> LfLSVO includes a few other options such as enabling Swimsuits and Sandy art style. 