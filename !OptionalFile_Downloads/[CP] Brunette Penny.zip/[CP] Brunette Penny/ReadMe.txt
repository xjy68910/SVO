This documentation is for users who want to use a matching Random Flower Queen character & portrait. You will need to know how to rename files and move files.


Step 1. Go to [CP] Brunette Penny\Portraits\RandomFlowerQueen & [CP] Brunette Penny\Characters\RandomFlowerQueen

Step 2. Go to [CP] Seasonal Villager Outfits\Portraits\RandomFlowerQueen & [CP] Seasonal Villager Outfits\Characters\RandomFlowerQueen

Step 3. Move the respective Penny_RFQ file to [CP] Seasonal Villager Outfits\Portraits\RandomFlowerQueen & [CP] Seasonal Villager Outfits\Characters\RandomFlowerQueen. You can drag + drop, cut, or copy + paste. Let it override the existing Penny_RFQ. Portraits go into the Portraits folder. Characters go into the Characters folder.

These steps will need to be redone every time SVO updates unless you keep a backup of your RandomFlowerQueen folder.

